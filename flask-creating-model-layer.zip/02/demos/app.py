from flaskr_carved_rock import create_app

create_app()