Here you can check out the source code state after each coding lesson in the module.

You should build a virtual environment with Python and install the requirements from the requirements.txt.

$ pip install -r requirements.txt

Then you can just copy the source code inside of the virtual environment folder and start up the flask server.

Warning:
I will not include the database file. You should run db_init.py script when the db is needed.

